package com.swiggy.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.swiggy.model.Cart;
import com.swiggy.model.Food;
import com.swiggy.repository.CartRepository;
import com.swiggy.repository.FoodRepository;

@Service("service")
public class SwiggyService {

	@Autowired
	FoodRepository foodRepository;

	@Autowired
	CartRepository cartRepository;

	@Transactional
	public List<Food> getFoodList() {
		List<Food> foodList = (List<Food>) foodRepository.findAll();
		return foodList;
	}

	/*   public void addFoodItem() {
		Food f1 = new Food("Burger", "North Indian", "burger.jpg", 150, 20);
		foodRepository.save(f1);
		Food f2 = new Food("Pizza", "North Indian", "pizza.jpg", 350, 30);
		foodRepository.save(f2);
		Food f3 = new Food("Chicken Biryani", "Mughlai", "biryani.jpg", 200, 25);
		Food f4 = new Food("Egg Roll", "North Indian", "eggroll.jpg", 60, 15);
		Food f5 = new Food("Noodles", "Chinese", "noodles.jpg", 120, 18);
		Food f6 = new Food("Maccroni", "French", "macroni.jpg", 150, 17);
		Food f7 = new Food("Butter Paneer", "North Indian", "butterpaneer.jpg", 250, 30);
		Food f8 = new Food("Butter Chicken", "Mughlai", "butterchicken.jpg", 350, 28);
		Food f9 = new Food("Hot Dog", "Fast Food", "hotdog.jpg", 150, 25);
		Food f10 = new Food("Sandwitch", "French", "sandwitch.jpg", 200, 35);
		Food f11 = new Food("Aloo Parathe", "Punjabi", "parathe.jpg", 70, 40);
		Food f12 = new Food("Chole Bhature", "Punjabi", "cholebhature.jpg", 100, 20);
		foodRepository.save(f3);
		foodRepository.save(f4);
		foodRepository.save(f5);
		foodRepository.save(f6);
		foodRepository.save(f7);
		foodRepository.save(f8);
		foodRepository.save(f9);
		foodRepository.save(f10);
		foodRepository.save(f11);
		foodRepository.save(f12);
	}*/

	@Transactional
	public List<Cart> getCartList(String userId) {
		List<Cart> cartList = (List<Cart>) cartRepository.findCartItemByUserid(userId);
		return cartList;
	}

	@Transactional
	public Food getfoodByid(int id) {
		Food food = foodRepository.findOne(id);
		return food;
	}

	@Transactional
	public void addToCart(Food food,String userId) {
		int id = food.getId();
		Food oldfood = foodRepository.findOne(id);
		int price = oldfood.getPrice();
		int totalCost = price * (oldfood.getQuantity() - food.getQuantity());
		Cart cart = new Cart();
		cart.setName(food.getName());
		cart.setPrice(totalCost);
		cart.setQuantity(oldfood.getQuantity() - food.getQuantity());
		cart.setUser_id(userId);
		cartRepository.save(cart);
		oldfood.setQuantity(food.getQuantity());

		foodRepository.save(oldfood);

	}

	@Transactional
	public boolean nameExistsInCart(String name,String userId) {
		boolean result = false;
		try {
			Cart cart = cartRepository.findByName(name,userId);
			System.out.println(cart.getId());
			if (cart.getId() > 0) {
				result = true;
			}
		} catch (NullPointerException e) {
			return false;
		}
		return result;
	}

	@Transactional
	public void updateCart(Food food, String userId) {
		int id = food.getId();
		Food oldfood = foodRepository.findOne(id);
		int price = oldfood.getPrice();
		int totalCost = price * (oldfood.getQuantity() - food.getQuantity());
		Cart cart = cartRepository.findByName(food.getName(),userId);
		cart.setPrice(cart.getPrice() + totalCost);
		cart.setQuantity(cart.getQuantity() + (oldfood.getQuantity() - food.getQuantity()));
		cartRepository.save(cart);
		oldfood.setQuantity(food.getQuantity());

		foodRepository.save(oldfood);

	}

	@Transactional
	public int getTotalCost(String userId) {
		int price=0;
		try
		{
	    price = cartRepository.calculateTotalCost(userId);
		}
		catch(NullPointerException e)
		{
			return 0;
		}
		return price;

	}

	@Transactional
	public void deleteFromCart(Cart cart, String userId) {
		Food food = foodRepository.findByName(cart.getName());
		Cart oldCart = cartRepository.findOne(cart.getId());
		int price = food.getPrice();
		int quantity = cart.getQuantity();
		int foodNewQuantity = oldCart.getQuantity() - cart.getQuantity();
		food.setQuantity(food.getQuantity() + foodNewQuantity);
		foodRepository.save(food);
		if (quantity == 0) {
			cartRepository.delete(cart);
		} else {
			cart.setPrice(quantity * price);
			cartRepository.save(cart);
		}

	}

	public void placeOrder(String userId) {
		List<Cart> cartList=cartRepository.findCartItemByUserid(userId);
		for(Cart c:cartList)
		{
			cartRepository.delete(c);
		}
		
	}

}

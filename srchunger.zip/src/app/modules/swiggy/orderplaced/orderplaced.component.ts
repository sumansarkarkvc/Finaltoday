import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderplaced',
  templateUrl: './orderplaced.component.html',
  styleUrls: ['./orderplaced.component.css']
})
export class OrderplacedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

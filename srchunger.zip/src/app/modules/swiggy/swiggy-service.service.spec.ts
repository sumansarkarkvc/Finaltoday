import { TestBed } from '@angular/core/testing';

import { SwiggyServiceService } from './swiggy-service.service';

describe('SwiggyServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SwiggyServiceService = TestBed.get(SwiggyServiceService);
    expect(service).toBeTruthy();
  });
});

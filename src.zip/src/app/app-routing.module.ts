import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ItemComponent } from './item/item.component';
import { CartComponent } from './cart/cart.component';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { RegistrationFormComponent } from './registration-form/registration-form.component';

const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"item", component:ItemComponent,  canActivate: [ AuthGuardService ]},
  {path:"cart",component:CartComponent,  canActivate: [ AuthGuardService ]},
  {path:"registration-form",component:RegistrationFormComponent},
  {path:'',redirectTo:"/login",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

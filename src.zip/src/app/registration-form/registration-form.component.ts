import { Component, OnInit} from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../authentication/services/auth.service';
import { Router } from '@angular/router';
import { User } from '../authentication/services/User';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit{
user:User;
invalidCredentialMsg: string;
  loginForm: FormGroup;
  submitted: boolean = false;
  constructor(private authService: AuthService, private router: Router,private formBuilder: FormBuilder) { 
  }
 ngOnInit() {
   this.loginForm = this.formBuilder.group({
     "name": ['', [Validators.required]],
     "phoneNumber": ['', [Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
      "email": ['', [Validators.required,Validators.email]],
      "password": ['', [Validators.required,Validators.minLength(5), Validators.maxLength(10)]]
    }) 
  }
  get f() { return this.loginForm.controls; }

onFormSubmit() {
		this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      console.log(this.loginForm.invalid);
      return;
    }
      this.authService.registerUser(this.user).subscribe(data => {
      console.log("User registered", data);
      this.router.navigate(['/login']);
    });

	  //  let name = this.loginForm.get('name').value;
    //  let phone = this.loginForm.get('phoneNumber').value;
    //  let mail = this.loginForm.get('email').value;
	  //  let pwd =this.loginForm.get('password').value;
	  
		   
	  
	}
}
	
       
 


